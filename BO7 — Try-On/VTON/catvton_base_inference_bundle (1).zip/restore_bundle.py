"""Restore exact source revisions/checkpoints for an exported BO7 research bundle."""
import hashlib,json,subprocess,sys
from pathlib import Path
from huggingface_hub import snapshot_download

config_path=Path(sys.argv[1]).resolve(); cfg=json.loads(config_path.read_text())
root=config_path.parent; models=root/'restored_models'; models.mkdir(exist_ok=True)
kind=cfg['export_model']; offline=cfg.get('offline_weights',{})
cfg['out']=str(root/'reproduced_outputs')

def clone(url,commit,dest):
    if not (dest/'.git').exists():
        subprocess.run(['git','clone','--no-checkout',url,str(dest)],check=True)
    subprocess.run(['git','-C',str(dest),'checkout','--detach',commit],check=True)
    actual=subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD'],text=True).strip()
    if actual!=commit: raise RuntimeError('Source revision mismatch')

if kind=='fashn':
    repo=models/'fashn-vton-1.5'; clone('https://github.com/fashn-AI/fashn-vton-1.5',cfg['fashn_commit'],repo)
    weights=root/offline['fashn'] if 'fashn' in offline else models/'fashn_weights'
    cfg.update(fashn_repo=str(repo),fashn_weights=str(weights))
    if 'fashn' not in offline:
        subprocess.run([sys.executable,str(repo/'scripts/download_weights.py'),'--weights-dir',str(weights)],check=True)
    expected=json.loads((root/'model_card.json').read_text())['weight_checksums']
    for relative,sha in expected.items():
        path=weights/relative; h=hashlib.sha256()
        if not path.exists(): raise FileNotFoundError(path)
        with path.open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
        if h.hexdigest()!=sha:
            raise RuntimeError('FASHN weight checksum changed. Restore the original cached weights: '+relative)
else:
    repo=models/'CatVTON'; clone('https://github.com/Zheng-Chong/CatVTON',cfg['cat_commit'],repo)
    cfg['cat_repo']=str(repo)
    patterns={'base':['unet/*','scheduler/*','feature_extractor/*','safety_checker/*','model_index.json'],
              'attention':['mix-48k-1024/attention/*'],
              'vae':['config.json','diffusion_pytorch_model.safetensors']}
    for key,spec in cfg['cat_checkpoints'].items():
        path_key='attn' if key=='attention' else key
        if path_key in offline: path=root/offline[path_key]
        else: path=Path(snapshot_download(spec['id'],revision=spec['revision'],allow_patterns=patterns[key]))
        cfg[path_key+'_path']=str(path)
config_path.write_text(json.dumps(cfg,indent=2))
print('Restored exact model inputs. Run the bundled inference worker with your own manifest.')
