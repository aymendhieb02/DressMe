import csv, hashlib, importlib.metadata as md, json, os, sys, time
from pathlib import Path
import numpy as np
from PIL import Image
import torch

def read_manifest(path):
    with open(path, newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError('Manifest contains no cases: ' + str(path))
    return rows

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def save_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, default=str))

def versions():
    out = {}
    for name in ['torch', 'torchvision', 'onnxruntime-gpu', 'fashn-vton',
                 'fashn-human-parser', 'diffusers', 'transformers', 'peft', 'accelerate']:
        try:
            out[name] = md.version(name)
        except md.PackageNotFoundError:
            out[name] = None
    return out

def append_record(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'a') as f:
        f.write(json.dumps(obj, default=str) + '\n')

def load_cat(cfg):
    sys.path.insert(0, cfg['cat_repo'])
    import model.pipeline as module
    original_vae = module.AutoencoderKL
    # The official constructor hard-codes a VAE ID. Redirect only its load path.
    class LocalVAE:
        @staticmethod
        def from_pretrained(*args, **kwargs):
            return original_vae.from_pretrained(cfg['vae_path'], local_files_only=True)
    module.AutoencoderKL = LocalVAE
    try:
        pipe = module.CatVTONPipeline(
            base_ckpt=cfg['base_path'], attn_ckpt=cfg['attn_path'],
            attn_ckpt_version='mix', weight_dtype=torch.float16, device='cuda:0',
            compile=False, use_tf32=False, skip_safety_check=True)
    finally:
        module.AutoencoderKL = original_vae
    if pipe.unet.config.in_channels != 9:
        raise RuntimeError('Expected official 9-channel inpainting UNet.')
    pipe.unet.eval().requires_grad_(False)
    pipe.vae.eval().requires_grad_(False)
    return pipe

def add_lora(unet, config):
    from peft import LoraConfig
    targets = [name for name, layer in unet.named_modules()
               if isinstance(layer, torch.nn.Linear) and '.attn1.' in name
               and name.endswith(('to_q', 'to_k', 'to_v', 'to_out.0'))]
    if not targets:
        raise RuntimeError('No self-attention projections found. Stop: model interface changed.')
    unet.requires_grad_(False)
    unet.add_adapter(LoraConfig(r=config['rank'], lora_alpha=config['alpha'],
                               target_modules=targets, lora_dropout=0.0,
                               bias='none', init_lora_weights=True))
    for name, param in unet.named_parameters():
        if param.requires_grad:
            if 'lora_' not in name:
                raise RuntimeError('Unexpected trainable base parameter: ' + name)
            param.data = param.data.float()
    return targets

def load_adapter(unet, folder):
    from peft import set_peft_model_state_dict
    from safetensors.torch import load_file
    config = json.loads((Path(folder) / 'bo7_adapter_config.json').read_text())
    add_lora(unet, config)
    result = set_peft_model_state_dict(unet, load_file(str(Path(folder) / 'adapter.safetensors')))
    missing = [name for name in result.missing_keys if 'lora_' in name]
    if missing or result.unexpected_keys:
        raise RuntimeError(f'Adapter mismatch: {missing}, {result.unexpected_keys}')
    unet.eval()
    return config

def module_digest(module, frozen_only=False):
    h=hashlib.sha256()
    for name,param in sorted(module.named_parameters()):
        if frozen_only and param.requires_grad: continue
        h.update(name.encode())
        data=param.detach().cpu().contiguous()
        h.update(str(data.dtype).encode()); h.update(str(tuple(data.shape)).encode())
        h.update(data.view(torch.uint8).numpy().tobytes())
    return h.hexdigest()

def check_train_validation(train_rows,val_rows):
    for rows in [train_rows,val_rows]:
        if not rows or any(str(r.get('paired','')).lower()!='true' for r in rows):
            raise ValueError('Both train and validation require verified paired supervision.')
    for key in ['case_id','group_id','person_sha256','garment_sha256','person_pixel_hash','garment_pixel_hash','person_identity']:
        left={str(r.get(key,'')) for r in train_rows if str(r.get(key,'')).strip()}
        right={str(r.get(key,'')) for r in val_rows if str(r.get(key,'')).strip()}
        if left & right: raise ValueError('Train/validation leakage: '+key)
