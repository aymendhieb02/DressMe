# Reproduce this research candidate
The base checkpoint and a LoRA adapter are different artifacts. This bundle includes inference code,
recorded settings/revisions/checksums and, when applicable, the separate adapter.

1. Use Python/Torch/CUDA matching the executed notebook environment.
2. Recreate the model-specific venv using notebook Cells 03/05 or 19 and its saved pip logs.
   The bundle also includes requirements.txt and the existing Torch constraints when recorded.
3. Run `python restore_bundle.py experiment_config.json` to fetch the recorded repository and checkpoints.
4. Fill input_template.csv with local images (CatVTON mask: white=replace, black=preserve).
5. Run `python fashn_worker.py experiment_config.json input_template.csv reproduced`
   or `python cat_worker.py experiment_config.json input_template.csv reproduced`.
   For the LoRA bundle, append `--adapter .` to the CatVTON command.

Review model_card.json and human evaluations before selecting this candidate for DressMe.
Keep person images/results private. These artifacts support inference research; they do not complete BO7.
