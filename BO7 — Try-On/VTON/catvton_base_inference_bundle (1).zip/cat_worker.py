import argparse, traceback
from common_worker import *

p=argparse.ArgumentParser()
p.add_argument('config'); p.add_argument('manifest'); p.add_argument('label')
p.add_argument('--adapter'); a=p.parse_args()
cfg=json.loads(Path(a.config).read_text())
run_id=str(time.time_ns())
start=time.perf_counter(); pipe=load_cat(cfg); load_s=time.perf_counter()-start
adapter_info=load_adapter(pipe.unet,a.adapter) if a.adapter else None
if adapter_info and (adapter_info['cat_commit']!=cfg['cat_commit'] or adapter_info['base_checkpoints']!=cfg['cat_checkpoints']):
    raise ValueError('Adapter was trained against different source/checkpoint revisions.')
for row in read_manifest(a.manifest):
    rec=dict(row,model='CatVTON-mix'+('-LoRA' if a.adapter else ''),run_label=a.label,run_id=run_id,
             model_revision=cfg['cat_commit'], checkpoints=cfg['cat_checkpoints'],
             dtype='torch.float16', device='cuda:0', seed=cfg['seed'], environment=versions(),
             settings=cfg['cat_settings'], mask_source=row.get('mask_source','supplied'),
             adapter=a.adapter,adapter_sha256=digest(Path(a.adapter)/'adapter.safetensors') if a.adapter else None,
             adapter_config=adapter_info,model_load_s=load_s,
             timing_scope='full official pipeline; supplied mask generation excluded',
             success=False,inference_s=None,peak_allocated_gib=None,peak_reserved_gib=None,
             output_width=None,output_height=None,output_path=None)
    try:
        person=Image.open(row['person_path']).convert('RGB')
        garment=Image.open(row['garment_path']).convert('RGB')
        mask=Image.open(row['mask_path']).convert('L')
        if mask.size != person.size:
            raise ValueError('Mask must align with the original person image.')
        values=set(np.unique(mask).tolist())
        if not values.issubset({0,255}) or len(values)!=2:
            raise ValueError('Expected nonempty binary 0/255 mask: white means replace.')
        rec.update(person_sha256=digest(row['person_path']),garment_sha256=digest(row['garment_path']),
                   mask_sha256=digest(row['mask_path']))
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats(0); start=time.perf_counter()
        # Official VAE posterior sampling uses global RNG in addition to the noise generator.
        torch.manual_seed(cfg['seed']); np.random.seed(cfg['seed'])
        generator=torch.Generator(device='cuda:0').manual_seed(cfg['seed'])
        image=pipe(image=person,condition_image=garment,mask=mask,
                   generator=generator,**cfg['cat_settings'])[0]
        torch.cuda.synchronize(); elapsed=time.perf_counter()-start
        output=Path(cfg['out'])/'outputs'/a.label/run_id/f"{row['case_id']}.png"
        output.parent.mkdir(parents=True,exist_ok=True); image.save(output)
        rec.update(success=True,inference_s=elapsed,
                   peak_allocated_gib=torch.cuda.max_memory_allocated(0)/2**30,
                   peak_reserved_gib=torch.cuda.max_memory_reserved(0)/2**30,
                   output_width=image.width,output_height=image.height,output_path=str(output),error=None)
    except Exception as exc:
        rec.update(success=False,error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc())
        append_record(Path(cfg['out'])/'runs'/f'{a.label}.jsonl',rec)
        raise
    append_record(Path(cfg['out'])/'runs'/f'{a.label}.jsonl',rec)
    print(row['case_id'],round(elapsed,2),'s',flush=True)
