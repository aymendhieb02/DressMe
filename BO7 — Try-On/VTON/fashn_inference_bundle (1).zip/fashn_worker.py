import argparse, sys, time, traceback
from common_worker import *

args = argparse.ArgumentParser()
args.add_argument('config'); args.add_argument('manifest'); args.add_argument('label')
args.add_argument('--repeats', type=int, default=1)
a = args.parse_args()
run_id = str(time.time_ns())
cfg = json.loads(Path(a.config).read_text())
sys.path.insert(0, str(Path(cfg['fashn_repo']) / 'src'))
import onnxruntime as ort
if ort.__version__ != '1.26.0':
    raise RuntimeError(f'Expected isolated ORT 1.26.0; imported {ort.__version__} from {ort.__file__}')
ort.preload_dlls()
from fashn_vton import TryOnPipeline
load_start = time.perf_counter()
pipe = TryOnPipeline(weights_dir=cfg['fashn_weights'], device='cuda:0')
load_seconds = time.perf_counter() - load_start
if cfg.get('fashn_dtype'):
    pipe.inference_dtype = getattr(torch, cfg['fashn_dtype'])
    pipe.tryon_model.to(dtype=pipe.inference_dtype)
    print('Precision override:', pipe.inference_dtype, flush=True)
sessions = {'detector': pipe.pose_model.pose_estimation.session_det,
            'pose': pipe.pose_model.pose_estimation.session_pose}
providers = {k: v.get_providers() for k,v in sessions.items()}
save_json(Path(cfg['out'])/'runtime'/'fashn_runtime.json', {
    'packages': versions(), 'torch_cuda': torch.version.cuda, 'ort_sessions': providers,
    'dtype': str(pipe.inference_dtype), 'native_bf16': torch.cuda.is_bf16_supported(including_emulation=False),
    'compute_capability': torch.cuda.get_device_capability(0), 'device': 'cuda:0',
    'load_seconds': load_seconds, 'fashn_commit': cfg['fashn_commit']})
print('ACTUAL ORT sessions:', providers, flush=True)
if any('CUDAExecutionProvider' not in v for v in providers.values()):
    raise RuntimeError('Pose session still uses CPU. Inspect logs and shared-library paths; do not benchmark silently.')

sample_times = []
sample_original = pipe._sample
def timed_sample(*args, **kwargs):
    torch.cuda.synchronize(); start = time.perf_counter()
    output = sample_original(*args, **kwargs)
    torch.cuda.synchronize(); sample_times.append(time.perf_counter() - start)
    return output
pipe._sample = timed_sample
rows = read_manifest(a.manifest)
for row in rows:
    for repeat in range(a.repeats):
        record = dict(row, model='FASHN-v1.5', run_label=a.label, run_id=run_id, repeat=repeat,
                      dtype=str(pipe.inference_dtype), model_revision=cfg['fashn_commit'],
                      settings=cfg['fashn_settings'], device='cuda:0',
                      timing_scope='full_pipeline; sample separately; decode excluded',
                      environment=versions(), ort_sessions=providers, model_load_s=load_seconds,
                      success=False,inference_s=None,peak_allocated_gib=None,peak_reserved_gib=None,
                      output_width=None,output_height=None,output_path=None)
        begin = time.perf_counter()
        sample_times.clear()
        try:
            person = Image.open(row['person_path']).convert('RGB')
            garment = Image.open(row['garment_path']).convert('RGB')
            record['input_decode_s'] = time.perf_counter() - begin
            record['person_sha256'] = digest(row['person_path'])
            record['garment_sha256'] = digest(row['garment_path'])
            torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats(0)
            start = time.perf_counter()
            result = pipe(person_image=person, garment_image=garment,
                          category=row['category'], garment_photo_type=row['garment_photo_type'],
                          **cfg['fashn_settings'])
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - start
            image = result.images[0]
            output = Path(cfg['out'])/'outputs'/a.label/run_id/f"{row['case_id']}_r{repeat}.png"
            output.parent.mkdir(parents=True, exist_ok=True); image.save(output)
            record.update(success=True, inference_s=elapsed, generation_s=sum(sample_times),
                          pre_post_s=elapsed - sum(sample_times),
                          peak_allocated_gib=torch.cuda.max_memory_allocated(0)/2**30,
                          peak_reserved_gib=torch.cuda.max_memory_reserved(0)/2**30,
                          output_width=image.width, output_height=image.height,
                          output_path=str(output), warmup=(repeat==0 and a.repeats>1), error=None)
        except Exception as exc:
            record.update(success=False, error=f'{type(exc).__name__}: {exc}',
                          traceback=traceback.format_exc(), output_path=None)
            append_record(Path(cfg['out'])/'runs'/f'{a.label}.jsonl', record)
            raise
        append_record(Path(cfg['out'])/'runs'/f'{a.label}.jsonl', record)
        print(row['case_id'], repeat, round(record['inference_s'],2), 's', flush=True)
